NEW REPOSITORY
echo "# joska-modern-mabati" >> README.md
git init
git add README.md
git commit -m "first commit"
git branch -M main
git remote add origin https://github.com/EricGikunguNyokabi/joska-modern-mabati.git
git push -u origin main

EXISTING REPOSITORY
git remote add origin https://github.com/EricGikunguNyokabi/joska-modern-mabati.git
git branch -M main
git push -u origin main